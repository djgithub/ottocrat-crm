<?php
class qCal extends qCal_Component_Vcalendar {
	// this is simply a facade to qCal_Component_Calendar, a shortcut
}
?>