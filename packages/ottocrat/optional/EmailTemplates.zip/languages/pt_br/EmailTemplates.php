<?php
/*+***********************************************************************************
 * The contents of this file are subject to the ottocrat CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  ottocrat CRM Open Source
 * The Initial Developer of the Original Code is ottocrat.
 * Portions created by ottocrat are Copyright (C) ottocrat.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Email Templates' => 'Email Templates' ,
	'LBL_ADD_RECORD' => 'Adicionar Email Template',
	'SINGLE_EmailTemplates' => 'Email Template',
	'LBL_EMAIL_TEMPLATES'=> 'Email Templates',
	'LBL_EMAIL_TEMPLATE' => 'Email Template',
	
	'LBL_TEMPLATE_NAME' => 'nome do modelo',
	'LBL_DESCRIPTION' => 'descrição',
	'LBL_SUBJECT' => 'assunto',
	'LBL_GENERAL_FIELDS' => 'Geral Campos',
	'LBL_SELECT_FIELD_TYPE' => 'Escolha um tipo de campo',
	
	'LBL_EMAIL_TEMPLATE_DESCRIPTION'=>'Gerenciar modelos de E -Mail módulo',
	
);
